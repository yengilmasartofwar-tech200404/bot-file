const express = require('express');
const multer = require('multer');
const { spawn, execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PASSWORD = process.env.ADMIN_PASSWORD;
if (!PASSWORD) {
  console.error('ADMIN_PASSWORD o\'rnatilmagan!');
  process.exit(1);
}

const BOTS_DIR = path.join(DATA_DIR, 'bots');
const TMP_DIR = path.join(DATA_DIR, 'tmp');
const DB_FILE = path.join(DATA_DIR, 'bots.json');
fs.mkdirSync(BOTS_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });

// ---------- holat ----------
let bots = {};
try { bots = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch {}
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(bots, null, 2));
const rts = {}; // runtime: { status, desired, child, logs }
const rt = (id) => (rts[id] ||= { status: 'stopped', desired: false, child: null, logs: [] });
const botDir = (id) => path.join(BOTS_DIR, id);

function addLog(id, text) {
  const r = rt(id);
  const time = new Date().toISOString().slice(11, 19);
  for (const line of String(text).split('\n')) {
    if (line.trim() === '') continue;
    r.logs.push(`[${time}] ${line}`);
  }
  if (r.logs.length > 1000) r.logs.splice(0, r.logs.length - 1000);
}

function parseEnv(text = '') {
  const env = {};
  for (const raw of text.split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    env[line.slice(0, i).trim()] = line.slice(i + 1).trim().replace(/^["']|["']$/g, '');
  }
  return env;
}

function childEnv(bot) {
  const base = { ...process.env, PYTHONUNBUFFERED: '1' };
  delete base.ADMIN_PASSWORD;
  delete base.PORT;
  return { ...base, ...parseEnv(bot.envText) };
}

// ---------- bot jarayonlari ----------
function runCmd(bot, cmd, env) {
  return new Promise((resolve) => {
    const r = rt(bot.id);
    addLog(bot.id, '$ ' + cmd);
    const c = spawn('sh', ['-c', cmd], { cwd: botDir(bot.id), env, detached: true });
    r.child = c;
    c.stdout.on('data', (d) => addLog(bot.id, d.toString()));
    c.stderr.on('data', (d) => addLog(bot.id, d.toString()));
    c.on('error', (e) => { addLog(bot.id, 'XATO: ' + e.message); resolve(1); });
    c.on('close', (code) => resolve(code));
  });
}

function defaultCmd(dir) {
  const has = (f) => fs.existsSync(path.join(dir, f));
  if (has('package.json')) {
    try {
      const p = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
      if (p.scripts && p.scripts.start) return 'npm start';
      if (p.main && has(p.main)) return 'node ' + p.main;
    } catch {}
    for (const f of ['index.js', 'bot.js', 'main.js', 'app.js']) if (has(f)) return 'node ' + f;
  }
  const py = has('.venv') ? '.venv/bin/python -u' : 'python3 -u';
  for (const f of ['main.py', 'bot.py', 'app.py', 'run.py', 'index.py']) if (has(f)) return py + ' ' + f;
  return null;
}

async function install(bot) {
  const dir = botDir(bot.id);
  const env = childEnv(bot);
  let ok = true;
  if (fs.existsSync(path.join(dir, 'package.json'))) {
    ok = (await runCmd(bot, 'npm install --omit=dev --no-audit --no-fund', env)) === 0;
  }
  if (ok && fs.existsSync(path.join(dir, 'requirements.txt'))) {
    ok = (await runCmd(bot, 'python3 -m venv .venv', env)) === 0 &&
         (await runCmd(bot, '.venv/bin/pip install --no-cache-dir -r requirements.txt', env)) === 0;
  }
  if (ok) fs.writeFileSync(path.join(dir, '.installed'), '1');
  return ok;
}

async function startBot(id) {
  const bot = bots[id];
  if (!bot) return;
  const r = rt(id);
  if (r.status === 'running' || r.status === 'installing') return;
  r.desired = true;
  bot.running = true;
  save();
  try {
    if (!fs.existsSync(path.join(botDir(id), '.installed'))) {
      r.status = 'installing';
      const ok = await install(bot);
      r.child = null;
      if (!ok) {
        r.status = r.desired ? 'error' : 'stopped';
        addLog(id, 'O\'rnatish muvaffaqiyatsiz tugadi');
        r.desired = false; bot.running = false; save();
        return;
      }
    }
    if (!r.desired) { r.status = 'stopped'; return; }
    const cmd = bot.cmd || defaultCmd(botDir(id));
    if (!cmd) {
      addLog(id, 'XATO: ishga tushirish buyrug\'i topilmadi. "Sozlamalar"da kiriting (masalan: python3 main.py)');
      r.status = 'error'; r.desired = false; bot.running = false; save();
      return;
    }
    r.status = 'running';
    const code = await runCmd(bot, cmd, childEnv(bot));
    r.child = null;
    r.status = 'stopped';
    addLog(id, `--- jarayon tugadi (kod ${code}) ---`);
    if (r.desired) {
      r.status = 'restarting';
      addLog(id, '5 soniyadan keyin qayta ishga tushadi...');
      setTimeout(() => {
        if (r.desired && r.status === 'restarting') { r.status = 'stopped'; startBot(id); }
      }, 5000);
    }
  } catch (e) {
    addLog(id, 'XATO: ' + e.message);
    r.status = 'error';
  }
}

function killChild(r, signal) {
  if (r.child && r.child.pid) {
    try { process.kill(-r.child.pid, signal); } catch {}
  }
}

function stopBot(id) {
  const bot = bots[id];
  if (!bot) return;
  const r = rt(id);
  r.desired = false;
  bot.running = false;
  save();
  if (r.child) {
    const c = r.child;
    killChild(r, 'SIGTERM');
    setTimeout(() => { if (r.child === c) killChild(r, 'SIGKILL'); }, 5000);
  } else {
    r.status = 'stopped';
  }
}

async function waitStopped(id, ms = 8000) {
  const r = rt(id);
  const t = Date.now();
  while (r.child && Date.now() - t < ms) await new Promise((x) => setTimeout(x, 200));
}

// ---------- zip ----------
function extractZip(zipPath, dir) {
  fs.mkdirSync(dir, { recursive: true });
  execFileSync('unzip', ['-o', '-q', zipPath, '-d', dir]);
  fs.rmSync(path.join(dir, '__MACOSX'), { recursive: true, force: true });
  // agar hammasi bitta papka ichida bo'lsa, ichkariga chiqaramiz
  const entries = fs.readdirSync(dir);
  if (entries.length === 1 && fs.statSync(path.join(dir, entries[0])).isDirectory()) {
    const inner = path.join(dir, entries[0]);
    const tmp = dir + '_flat_' + Date.now();
    fs.renameSync(inner, tmp);
    fs.rmSync(dir, { recursive: true, force: true });
    fs.renameSync(tmp, dir);
  }
}

// ---------- server ----------
const app = express();

app.use((req, res, next) => {
  const h = req.headers.authorization || '';
  const [scheme, b64] = h.split(' ');
  if (scheme === 'Basic' && b64) {
    const pass = Buffer.from(b64, 'base64').toString().split(':').slice(1).join(':');
    const a = crypto.createHash('sha256').update(pass).digest();
    const b = crypto.createHash('sha256').update(PASSWORD).digest();
    if (crypto.timingSafeEqual(a, b)) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Bot Host"').status(401).send('Parol kerak');
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
const upload = multer({ dest: TMP_DIR, limits: { fileSize: 200 * 1024 * 1024 } });

const view = (b) => ({
  id: b.id, name: b.name, envText: b.envText || '', cmd: b.cmd || '',
  status: rt(b.id).status, autoCmd: defaultCmd(botDir(b.id)),
});

app.get('/api/bots', (req, res) => res.json(Object.values(bots).map(view)));

app.post('/api/bots', upload.single('zip'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'ZIP fayl tanlanmagan' });
    const id = crypto.randomBytes(4).toString('hex');
    extractZip(req.file.path, botDir(id));
    fs.rmSync(req.file.path, { force: true });
    bots[id] = {
      id, name: (req.body.name || 'bot-' + id).trim(),
      envText: req.body.envText || '', cmd: '', running: false,
    };
    save();
    addLog(id, 'Fayllar yuklandi');
    res.json(view(bots[id]));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/bots/:id/code', upload.single('zip'), async (req, res) => {
  const bot = bots[req.params.id];
  if (!bot || !req.file) return res.status(404).json({ error: 'Topilmadi' });
  try {
    const wasRunning = rt(bot.id).desired;
    stopBot(bot.id);
    await waitStopped(bot.id);
    fs.rmSync(botDir(bot.id), { recursive: true, force: true });
    extractZip(req.file.path, botDir(bot.id));
    fs.rmSync(req.file.path, { force: true });
    addLog(bot.id, 'Kod yangilandi');
    if (wasRunning) startBot(bot.id);
    res.json(view(bot));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/bots/:id', (req, res) => {
  const bot = bots[req.params.id];
  if (!bot) return res.status(404).json({ error: 'Topilmadi' });
  if (typeof req.body.name === 'string' && req.body.name.trim()) bot.name = req.body.name.trim();
  if (typeof req.body.envText === 'string') bot.envText = req.body.envText;
  if (typeof req.body.cmd === 'string') bot.cmd = req.body.cmd.trim();
  save();
  res.json(view(bot));
});

app.post('/api/bots/:id/start', (req, res) => {
  if (!bots[req.params.id]) return res.status(404).end();
  startBot(req.params.id);
  res.json({ ok: true });
});

app.post('/api/bots/:id/stop', (req, res) => {
  if (!bots[req.params.id]) return res.status(404).end();
  stopBot(req.params.id);
  res.json({ ok: true });
});

app.post('/api/bots/:id/restart', async (req, res) => {
  const id = req.params.id;
  if (!bots[id]) return res.status(404).end();
  stopBot(id);
  await waitStopped(id);
  if (req.query.reinstall) fs.rmSync(path.join(botDir(id), '.installed'), { force: true });
  startBot(id);
  res.json({ ok: true });
});

app.delete('/api/bots/:id', async (req, res) => {
  const id = req.params.id;
  if (!bots[id]) return res.status(404).end();
  stopBot(id);
  await waitStopped(id);
  fs.rmSync(botDir(id), { recursive: true, force: true });
  delete bots[id]; delete rts[id];
  save();
  res.json({ ok: true });
});

app.get('/api/bots/:id/logs', (req, res) => {
  if (!bots[req.params.id]) return res.status(404).end();
  const r = rt(req.params.id);
  res.json({ status: r.status, logs: r.logs.slice(-400).join('\n') });
});

app.listen(PORT, () => {
  console.log('Bot Host ishga tushdi, port ' + PORT);
  for (const b of Object.values(bots)) if (b.running) startBot(b.id);
});

// Render qayta deploy qilganda botlarni to'xtatamiz (keyin avtomatik qayta yonadi)
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    for (const r of Object.values(rts)) { r.desired = false; killChild(r, 'SIGTERM'); }
    setTimeout(() => process.exit(0), 1500);
  });
}
